<?php

/*
Plugin Name: Top News User Social Profile
Plugin URI: https://themeforest.net/user/codexcoder/portfolio
Description: Custom social profile fields for user will be added after installing this plugins. This plugin is only for Top News wordpress theme
Author: CodexCoder
Author URI: https://www.codexcoder.com/
Version: 1.0.1
Text Domain: top-news
*/

function top_news_admin_menu_enqueue_style() {
    wp_enqueue_style('admin-menu-style', plugins_url( 'css/admin-menu-style.css', __FILE__ ), null);
}
add_action( 'admin_enqueue_scripts', 'top_news_admin_menu_enqueue_style');


//add custom user profile field
function top_news_modify_contact_methods($profile_fields) {

        // Add new fields
        $profile_fields['tn_user_facebook'] = 'Facebook Profile Url';
        $profile_fields['tn_user_twitter'] = 'Twitter Username';                
        $profile_fields['tn_user_gplus'] = 'Google+ Profile URL';
        $profile_fields['tn_user_linkedin'] = 'LinkedIn Profile Url';
        $profile_fields['tn_user_tumblr'] = 'Tumblr Profile Url';
        $profile_fields['tn_user_vimeo'] = 'Vimeo Profile Url';
        $profile_fields['tn_user_rss'] = 'RSS Profile Url';
        $profile_fields['tn_user_behance'] = 'Behance Url';

        return $profile_fields;
}
add_filter('user_contactmethods', 'top_news_modify_contact_methods');